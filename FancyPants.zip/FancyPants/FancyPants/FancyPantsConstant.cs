﻿namespace System.TransactCampus.FancyPants
{
    internal static class FancyPantsConstant
    {
        internal static readonly string InvalidConfirmMessage = "Your input is "+
            "not valid. Enter y or Y to calculate the result.";

        internal static readonly string CalculateResultConfirmation = "Enter y or Y to calculate" +
            "result:";

        internal static readonly string InvalidData = "Sorry..System cannot proceed with the calculation because you provide some invalid input. " +
                    "Please check the inputs and try again";

        internal static readonly string LowValueLabel = "Enter Low value: ";

        internal static readonly string HighValueLabel = "Enter High value: ";

        internal static readonly string AValueLabel = "Enter A value: ";

        internal static readonly string BValueLabel = "Enter B value: ";
    }
}
