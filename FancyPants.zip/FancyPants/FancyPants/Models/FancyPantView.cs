﻿namespace System.TransactCampus.FancyPants.Model
{
    /// <summary>
    /// Fancy Pant View Model for User Inputs
    /// </summary>
    public class FancyPantView
    {
        /// <summary>
        /// Get or Set Low Value
        /// </summary>
        public string Low { get; set; }

        /// <summary>
        /// Get or Set High Value
        /// </summary>
        public string High { get; set; }

        /// <summary>
        /// Get or Set A Value
        /// </summary>
        public string A { get; set; }

        /// <summary>
        /// Get or Set B Value
        /// </summary>
        public string B { get; set; }
    }
}
