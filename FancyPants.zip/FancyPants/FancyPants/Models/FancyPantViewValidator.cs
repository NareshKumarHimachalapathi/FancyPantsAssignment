﻿namespace System.TransactCampus.FancyPants.Model
{
    using FluentValidation;
    using System.Text.RegularExpressions;

    public class FancyPantViewValidator : AbstractValidator<FancyPantView>
    {
        public FancyPantViewValidator()
        {
            var regEx = new Regex("^[0-9]+$"); 

            RuleFor(x => x.High)
                .NotEmpty()
                .Matches(regEx)
                ;

            RuleFor(x => x.Low)
                .NotEmpty()
                .Matches(regEx)
                ;

            RuleFor(x => x.A)
                .NotEmpty()
                .Matches(regEx)
                ;

            RuleFor(x => x.B)
                .NotEmpty()
                .Matches(regEx)
                ;
        }
    }
}
