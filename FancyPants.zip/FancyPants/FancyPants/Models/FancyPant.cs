﻿namespace System.TransactCampus.FancyPants.Model
{
    /// <summary>
    /// Fancy Pant Service Model.
    /// </summary>
    public class FancyPant
    {
        public int[] ValuesTobeSorted = new int[4];
        public FancyPant(string low, string high, string a, string b)
        {
            if (!string.IsNullOrEmpty(low) && !string.IsNullOrEmpty(high)&&
                !string.IsNullOrEmpty(a) && !string.IsNullOrEmpty(b))
            {
                ValuesTobeSorted[0] = Convert.ToInt32(low);
                ValuesTobeSorted[1] = Convert.ToInt32(high);
                ValuesTobeSorted[2] = Convert.ToInt32(a);
                ValuesTobeSorted[3] = Convert.ToInt32(b);
                Array.Sort(ValuesTobeSorted); 
            }
        }
    }
}
