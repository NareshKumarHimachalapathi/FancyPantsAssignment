﻿namespace System.TransactCampus.FancyPants.Service
{
    using Microsoft.Extensions.Logging;
    using System.TransactCampus.FancyPants.Extensions;
    using System.TransactCampus.FancyPants.Model;

    /// <summary>
    /// Fancy Pant calculator Implementation Class.
    /// </summary>
    public class CalculateService : ICalculateService
    {
        /// <summary>
        /// Fancy Pant calculator
        /// </summary>
        /// <param name="fancyPant">fancy pant service model</param>
        /// <param name="logger">logger</param>
        public void Compute(FancyPant fancyPant, ILogger<Program> logger)
        {
            try
            {
                foreach (var item in fancyPant.ValuesTobeSorted)
                {
                    if (item % fancyPant.ValuesTobeSorted[2] == 0 && fancyPant.ValuesTobeSorted[3] == 0)
                    {
                        Console.WriteLine("FancyPants");
                    }
                    else if (item % fancyPant.ValuesTobeSorted[2] == 0)
                    {
                        Console.WriteLine("Fancy");
                    }
                    else if (item % fancyPant.ValuesTobeSorted[3] == 0)
                    {
                        Console.WriteLine("Pants");
                    }
                    else
                    {
                        Console.WriteLine(item);
                    }
                }
            }
            catch (Exception ex)
            {
                logger.LogError("Error Occured while calculating Fancy Pant", ex.ToLogString());
            }
        }
    }
}
