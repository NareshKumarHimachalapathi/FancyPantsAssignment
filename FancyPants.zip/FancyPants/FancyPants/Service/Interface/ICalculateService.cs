﻿namespace System.TransactCampus.FancyPants.Service
{
    using Microsoft.Extensions.Logging;
    using System.TransactCampus.FancyPants.Model;

    /// <summary>
    /// Interface to calculate the service
    /// </summary>
    interface ICalculateService
    {
        /// <summary>
        /// Fancy Pant calculator
        /// </summary>
        /// <param name="fancyPant">fancy pant service model</param>
        /// <param name="logger">logger</param>
        void Compute(FancyPant fancyPant, ILogger<Program> logger);
    }
}
