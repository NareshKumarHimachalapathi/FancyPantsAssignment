﻿namespace System.TransactCampus.FancyPants.Extensions
{
    using System.Text;
    /// <summary>
    /// Exception Extension Class.
    /// </summary>
    internal static class ExceptionExtensions
    {
        /// <summary>
        /// ToLogString Extension method for Exception.
        /// </summary>
        /// <param name="ex"></param>
        /// <returns>string.</returns>
        internal static string ToLogString(this Exception ex)
        {
            var exMessage = new StringBuilder();
            if (ex != null)
            {
                var Ex = ex;
                exMessage.Append(Environment.NewLine);
                exMessage.Append("Exception:");
                exMessage.Append(Environment.NewLine);
                while (Ex != null)
                {
                    exMessage.Append(Ex.Message);
                    exMessage.Append(Environment.NewLine);
                    Ex = Ex.InnerException;
                }

                LogMessage(ex, exMessage);

                LogData(ex, exMessage);

                LogStackTrace(ex, exMessage);

                LogSource(ex, exMessage);

                LogTargetSite(ex, exMessage);

                LogBaseException(ex, exMessage);
            }
            return exMessage.ToString();
        }

        private static void LogBaseException(Exception ex, StringBuilder exMessage)
        {
            var baseException = ex.GetBaseException();
            if (baseException != null)
            {
                exMessage.Append("BaseException:");
                exMessage.Append(Environment.NewLine);
                exMessage.Append(ex.GetBaseException());
            }
        }

        private static void LogTargetSite(Exception ex, StringBuilder exMessage)
        {
            if (ex.TargetSite != null)
            {
                exMessage.Append("TargetSite:");
                exMessage.Append(Environment.NewLine);
                exMessage.Append(ex.TargetSite.ToString());
                exMessage.Append(Environment.NewLine);
            }
        }

        private static void LogSource(Exception ex, StringBuilder exMessage)
        {
            if (ex.Source != null)
            {
                exMessage.Append("Source:");
                exMessage.Append(Environment.NewLine);
                exMessage.Append(ex.Source);
                exMessage.Append(Environment.NewLine);
            }
        }

        private static void LogStackTrace(Exception ex, StringBuilder exMessage)
        {
            if (ex.StackTrace != null)
            {
                exMessage.Append("StackTrace:");
                exMessage.Append(Environment.NewLine);
                exMessage.Append(ex.StackTrace.ToString());
                exMessage.Append(Environment.NewLine);
            }
        }

        private static void LogData(Exception ex, StringBuilder exMessage)
        {
            if (ex.Data != null)
            {
                foreach (var dataItem in ex.Data)
                {
                    exMessage.Append("Data:");
                    exMessage.Append(dataItem.ToString());
                    exMessage.Append(Environment.NewLine);
                }
            }
        }

        private static void LogMessage(Exception ex, StringBuilder exMessage)
        {
            if (!string.IsNullOrEmpty(ex.Message))
            {
                exMessage.Append(Environment.NewLine);
                exMessage.Append($"Message: {ex.Message}");
                exMessage.Append(Environment.NewLine);
            }
        }
    }
}
