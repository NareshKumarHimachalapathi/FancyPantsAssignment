﻿namespace System.TransactCampus.FancyPants
{
    using Microsoft.Extensions.DependencyInjection;
    using Microsoft.Extensions.Logging;
    using System.TransactCampus.FancyPants.Model;
    using System.TransactCampus.FancyPants.Service;
    public class Program
    {
        static void Main(string[] args)
        {
            //setup our DI
            var serviceProvider = new ServiceCollection()
                .AddLogging()
                .AddTransient<ICalculateService, CalculateService>()
                .BuildServiceProvider();

            //configure console logging
            var logger = serviceProvider.GetService<ILoggerFactory>()
            .CreateLogger<Program>();

            //Perform Calculation
            var fancyPantView = ReadInputs();
            Console.Write(FancyPantsConstant.CalculateResultConfirmation);
            var calculateInput = Console.ReadLine();
            if (calculateInput == "y" || calculateInput == "Y")
            {
                PerformCalculation(serviceProvider, logger, fancyPantView);
            }
            else
            {
                Console.Write(FancyPantsConstant.InvalidConfirmMessage);
            }


            Console.ReadLine();
        }

        private static void PerformCalculation(ServiceProvider serviceProvider, ILogger<Program> logger, FancyPantView fancyPantView)
        {
            //validate input using fluent validation
            var validator = new FancyPantViewValidator();
            var validRes = validator.Validate(fancyPantView);
            if (validRes.IsValid)
            {
                var fancyPant = MapViewModelToServiceModel(fancyPantView);

                //do the actual work here
                var calculateService = serviceProvider.GetService<ICalculateService>();
                calculateService.Compute(fancyPant, logger);
            }
            else
            {
                Console.Write(FancyPantsConstant.InvalidData);
            }
        }

        private static FancyPant MapViewModelToServiceModel(FancyPantView fancyPantView)
        {
            return new FancyPant(fancyPantView.Low, fancyPantView.High,
                            fancyPantView.A, fancyPantView.B);
        }

        private static FancyPantView ReadInputs()
        {
            var fancyPantView = new FancyPantView();
            Console.Write(FancyPantsConstant.LowValueLabel);
            fancyPantView.Low = Console.ReadLine();
            Console.Write(FancyPantsConstant.HighValueLabel);
            fancyPantView.High = Console.ReadLine();
            Console.Write(FancyPantsConstant.AValueLabel);
            fancyPantView.A = Console.ReadLine();
            Console.Write(FancyPantsConstant.BValueLabel);
            fancyPantView.B = Console.ReadLine();
            return fancyPantView;
        }
    }
}
